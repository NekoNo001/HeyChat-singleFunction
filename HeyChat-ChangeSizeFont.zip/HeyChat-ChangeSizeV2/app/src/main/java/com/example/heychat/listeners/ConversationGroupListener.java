package com.example.heychat.listeners;

import com.example.heychat.models.Group;

public interface ConversationGroupListener {
    void onConversionGroupClicker(Group group);
}
