package com.example.heychat.models;

public class FontSize {
    public static int fontsize = 18;
}
