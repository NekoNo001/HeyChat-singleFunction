package com.example.heychat.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.heychat.R;

public class PrivateChatActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_private_chat);
    }
}