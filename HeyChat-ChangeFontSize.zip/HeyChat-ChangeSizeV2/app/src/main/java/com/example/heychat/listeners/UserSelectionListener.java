package com.example.heychat.listeners;

public interface UserSelectionListener {

    void onUserSelection(Boolean isSelected);

}
