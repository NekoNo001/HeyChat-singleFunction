package com.example.heychat.listeners;

import com.example.heychat.models.User;

public interface UserListener {

    void onUserClicker(User user);

}
