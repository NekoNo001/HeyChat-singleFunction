package com.example.heychat.listeners;

import com.example.heychat.models.Group;

public interface GroupListener {
    void onGroupClicker(Group group);
}
